import static org.junit.Assert.*;

import org.junit.Test;

public class BinaryTreeTest {

	public void testLca()
	{
		BinaryTreeTest test = new BinaryTreeTest();
		Node nullNode= null;
		int i = 5;
		int k =6;
		Node result = test.lca(nullNode,i,k);
		
	}


}
